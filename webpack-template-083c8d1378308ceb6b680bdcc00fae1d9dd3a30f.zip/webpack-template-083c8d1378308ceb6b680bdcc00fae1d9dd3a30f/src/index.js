
import './js/common'
import './css/main.css'
import './scss/main.scss'

// import Bootstrap from 'bootstrap/dist/css/bootstrap.min.css'
// import 'bootstrap/dist/css/bootstrap.min.css'

// import 'vue'
// import Vue from 'vue'
window.Vue = require('vue')

